﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;


namespace ConsoleApp4
{
    class Program
    {
        static void Main(string[] args)
        {
            double a, b, c, d, y;
            Console.WriteLine("Vvedite a");
            a = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Vvedite b");
            b = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Vvedite c");
            c = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Vvedite d");
            d = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine(y = 1 / Math.Pow(a, 2) * (Math.Pow(b / 10, 3)) * (Math.Pow(c + d, 2)));
            Console.ReadLine();
            


        }
        

    }
   

}
